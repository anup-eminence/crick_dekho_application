package com.example.cricdekho.data.model

data class FantasyList(val title: String)
