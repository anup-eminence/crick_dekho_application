package com.example.cricdekho.ui.matchdetails

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemInfoTeam2Binding
import com.example.cricdekho.data.model.InfoTeamList
import easyadapter.dc.com.library.EasyAdapter

class InfoTeam2Adapter : EasyAdapter<InfoTeamList, ItemInfoTeam2Binding>(R.layout.item_info_team2) {
    override fun onBind(binding: ItemInfoTeam2Binding, model: InfoTeamList) {
        binding.apply {
            ivPlayer.setImageResource(model.profile)
            tvName.text = model.playerName
            tvExpert.text = model.playerExpert
        }
    }

    override fun onCreatingHolder(binding: ItemInfoTeam2Binding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
    }
}