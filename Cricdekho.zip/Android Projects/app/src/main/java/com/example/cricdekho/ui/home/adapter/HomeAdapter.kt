package com.example.cricdekho.ui.home.adapter

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemHomeBinding
import com.example.cricdekho.data.model.HomeList
import easyadapter.dc.com.library.EasyAdapter

class HomeAdapter : EasyAdapter<HomeList, ItemHomeBinding>(R.layout.item_home) {
    override fun onBind(binding: ItemHomeBinding, model: HomeList) {
        binding.apply {
            ivFlag1.setImageResource(model.flag1)
            ivFlag2.setImageResource(model.flag2)
            tvTitle1.text = model.match1
            tvTitle2.text = model.match2
            tvTitle3.text = model.title
            tvRuns1.text = model.runs1
            tvRuns2.text = model.runs2
        }
    }

    override fun onCreatingHolder(binding: ItemHomeBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
        binding.tvSchedule.setOnClickListener(easyHolder.clickListener)
        binding.tvPoints.setOnClickListener(easyHolder.clickListener)
        binding.clItem.setOnClickListener(easyHolder.clickListener)
    }
}