package com.example.cricdekho.data.model

data class VideoList(val image: Int, val text: String, val time: String)
