package com.example.cricdekho.ui.schedulepoints.schedule

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cricdekho.R
import com.example.cricdekho.databinding.FragmentScheduleBinding
import com.example.cricdekho.data.model.ScheduleList

class ScheduleFragment : Fragment() {
    private lateinit var binding: FragmentScheduleBinding
    private lateinit var scheduleAdapter: ScheduleAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentScheduleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initView()
    }

    private fun initView() {
        setUpAdapter()
    }

    private fun setUpAdapter() {
        scheduleAdapter = ScheduleAdapter()
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        val scheduleList = ArrayList<ScheduleList>()
        for (i in 1..8) {
            scheduleList.add(
                ScheduleList(
                    "2 Feb",
                    "South Africa Women vs Australia women >",
                    R.drawable.ic_nz,
                    R.drawable.ic_nz,
                    "South Africa",
                    "New Zealand XI",
                    "149/9 (20 ov)",
                    "149/9 (20 ov)",
                    "Match Delayed Due To Rain"
                )
            )
        }
        scheduleAdapter.addAll(scheduleList, false)
        binding.recyclerView.adapter = scheduleAdapter
        scheduleAdapter.notifyDataSetChanged()

        scheduleAdapter.setRecyclerViewItemClick { itemView, model ->
            when (itemView.id) {
                R.id.clItem -> {
                    findNavController().navigate(R.id.action_matchesFragment_to_matchDetailsFragment)
                }
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) = ScheduleFragment().apply {
            arguments = Bundle().apply {}
        }
    }
}