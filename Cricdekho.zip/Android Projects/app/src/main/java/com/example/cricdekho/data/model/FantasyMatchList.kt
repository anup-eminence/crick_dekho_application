package com.example.cricdekho.data.model

data class FantasyMatchList(
    val title: String,
    val image1: Int,
    val image2: Int,
    val time: String,
    val match1: String,
    val match2: String
)