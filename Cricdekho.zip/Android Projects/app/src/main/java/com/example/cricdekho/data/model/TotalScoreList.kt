package com.example.cricdekho.data.model

data class TotalScoreList(
    val player: String,
    val txt: String,
    val r: String,
    val b: String,
    val _4s: String,
    val _6s: String,
    val sr: String
)
