package com.example.cricdekho.data.model

data class BowlersList(
    val player: String,
    val o: String,
    val m: String,
    val r: String,
    val w: String,
    val eco: String
)
