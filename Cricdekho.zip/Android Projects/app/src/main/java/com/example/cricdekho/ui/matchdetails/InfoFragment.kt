package com.example.cricdekho.ui.matchdetails

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cricdekho.R
import com.example.cricdekho.databinding.FragmentInfoBinding
import com.example.cricdekho.data.model.InfoTeamList

class InfoFragment : Fragment() {
    private lateinit var binding: FragmentInfoBinding
    private lateinit var infoTeam1Adapter: InfoTeam1Adapter
    private lateinit var infoTeam2Adapter: InfoTeam2Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentInfoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initView()
        setOnClickListener()
    }

    private fun initView() {
        binding.apply {
            txtToss.text = "England Lions elected to bowl"
            txtMatch.text = "3rd unofficial Test\nIndia A v England Lions 2024"
            txtDateTime.text = "01 February, Thu 09:30 AM IST"
            txtVenue.text = "Narendra Modi Stadium, Ahmedabad"
            txtUmpires.text = "Mohit Krishnadas (India), Vinod Seshan (India)"
        }
        setUpTeam1Adapter()
        setUpTeam2Adapter()
    }

    private fun setOnClickListener() {
        binding.tvSchedule.setOnClickListener {
            findNavController().navigate(R.id.action_matchDetailsFragment_to_schedulePointsFragment)
        }
    }

    private fun setUpTeam1Adapter() {
        infoTeam1Adapter = InfoTeam1Adapter()
        binding.recyclerViewTeam1.layoutManager = LinearLayoutManager(requireContext())
        val infoTeamList = ArrayList<InfoTeamList>()
        for (i in 1..11) {
            infoTeamList.add(
                InfoTeamList(
                    R.drawable.ic_player, "Sai Sudharsan", "All"
                )
            )
        }
        infoTeam1Adapter.addAll(infoTeamList, false)
        binding.recyclerViewTeam1.adapter = infoTeam1Adapter
        infoTeam1Adapter.notifyDataSetChanged()
    }

    private fun setUpTeam2Adapter() {
        infoTeam2Adapter = InfoTeam2Adapter()
        binding.recyclerViewTeam2.layoutManager = LinearLayoutManager(requireContext())
        val infoTeamList = ArrayList<InfoTeamList>()
        for (i in 1..11) {
            infoTeamList.add(
                InfoTeamList(
                    R.drawable.ic_player, "James Coles", "All"
                )
            )
        }
        infoTeam2Adapter.addAll(infoTeamList, false)
        binding.recyclerViewTeam2.adapter = infoTeam2Adapter
        infoTeam2Adapter.notifyDataSetChanged()
    }

    companion object {
        @JvmStatic
        fun newInstance() = InfoFragment().apply {
            arguments = Bundle().apply {}
        }
    }
}