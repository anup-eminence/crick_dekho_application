package com.example.cricdekho.data.model

data class HomeList(
    val flag1: Int, val flag2: Int, val match1: String, val match2: String, val title: String, val runs1: String, val runs2: String
)
