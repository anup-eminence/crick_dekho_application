package com.example.cricdekho.data.model

data class WicketsList(
    val player: String,
    val txt: String,
    val score: String,
    val over: String,
)
