package com.example.cricdekho.data.model

data class PointTableList(
    val number: String,
    val flag: Int,
    val player: String,
    val p: String,
    val w: String,
    val l: String,
    val d: String,
    val nrr: String,
    val pts: String
)
