package com.example.cricdekho.ui.fantasy

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cricdekho.R
import com.example.cricdekho.databinding.FragmentFantasyBinding
import com.example.cricdekho.data.model.FantasyList
import com.example.cricdekho.data.model.FantasyMatchList
import com.example.cricdekho.ui.fantasy.adapter.FantasyAdapter
import com.example.cricdekho.ui.fantasy.adapter.FantasyMatchesAdapter

class FantasyFragment : Fragment() {
    private lateinit var binding: FragmentFantasyBinding
    private lateinit var fantasyAdapter: FantasyAdapter
    private lateinit var fantasyMatchesAdapter: FantasyMatchesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFantasyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initView()
    }

    private fun initView() {
        setUpFantasyAdapter()
        setUpFantasyMatchAdapter()
    }

    @SuppressLint("ResourceAsColor")
    private fun setUpFantasyAdapter() {
        fantasyAdapter = FantasyAdapter()
        binding.recyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        val fantasyList = ArrayList<FantasyList>()
        for (i in 1..8) {
            fantasyList.add(
                FantasyList(
                    "Upcoming match"
                )
            )
        }
        fantasyAdapter.addAll(fantasyList, false)
        binding.recyclerView.adapter = fantasyAdapter
        fantasyAdapter.notifyDataSetChanged()

        fantasyAdapter.setRecyclerViewItemClick { itemView, model ->
            when (itemView.id) {
                R.id.tvText -> {

                }
            }
        }
    }

    private fun setUpFantasyMatchAdapter() {
        fantasyMatchesAdapter = FantasyMatchesAdapter()
        binding.recyclerViewMatches.layoutManager =
            LinearLayoutManager(requireContext())
        val fantasyMatchList = ArrayList<FantasyMatchList>()
        for (i in 1..15) {
            fantasyMatchList.add(
                FantasyMatchList(
                    "South Africa tour of New Zealand",
                    R.drawable.ic_in,
                    R.drawable.ic_nz,
                    "11 days left",
                    "NZ",
                    "SA"
                )
            )
        }
        fantasyMatchesAdapter.addAll(fantasyMatchList, false)
        binding.recyclerViewMatches.adapter = fantasyMatchesAdapter
        fantasyMatchesAdapter.notifyDataSetChanged()

        fantasyMatchesAdapter.setRecyclerViewItemClick { itemView, model ->
            when (itemView.id) {
                R.id.clItem -> {
                    findNavController().navigate(R.id.action_fantasyFragment_to_matchDetailsFragment)
                }
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FantasyFragment().apply {
                arguments = Bundle().apply {
                }
            }
    }
}