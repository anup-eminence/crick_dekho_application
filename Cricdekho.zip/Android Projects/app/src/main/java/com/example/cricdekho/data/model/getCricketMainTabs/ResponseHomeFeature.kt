package com.example.cricdekho.data.model.getCricketMainTabs

data class ResponseHomeFeature(
    val `data`: List<Data>,
    val message: String
)