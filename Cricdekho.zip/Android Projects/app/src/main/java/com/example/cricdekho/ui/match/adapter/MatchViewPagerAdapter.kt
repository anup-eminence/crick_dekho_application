package com.example.cricdekho.ui.match.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.cricdekho.ui.schedulepoints.schedule.ScheduleFragment

class MatchViewPagerAdapter(fragmentActivity: FragmentActivity) :
    FragmentStateAdapter(fragmentActivity) {
    override fun getItemCount(): Int {
        return 3
    }

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> ScheduleFragment()
            1 -> ScheduleFragment()
            2 -> ScheduleFragment()
            else -> throw IndexOutOfBoundsException("Invalid position $position")
        }
    }
}