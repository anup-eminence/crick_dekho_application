package com.example.cricdekho.ui.schedulepoints.schedule

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemScheduleBinding
import com.example.cricdekho.data.model.ScheduleList
import easyadapter.dc.com.library.EasyAdapter

class ScheduleAdapter : EasyAdapter<ScheduleList, ItemScheduleBinding>(R.layout.item_schedule) {
    override fun onBind(binding: ItemScheduleBinding, model: ScheduleList) {
        binding.apply {
            ivFlag1.setImageResource(model.flag1)
            ivFlag2.setImageResource(model.flag2)
            tvDate.text = model.date
            tvMatch.text = model.title
            tvTitle1.text = model.match1
            tvTitle2.text = model.match2
            tvRuns1.text = model.runs1
            tvRuns2.text = model.runs2
            tvDecision.text = model.decision
        }
    }

    override fun onCreatingHolder(binding: ItemScheduleBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
        binding.clItem.setOnClickListener(easyHolder.clickListener)
    }
}