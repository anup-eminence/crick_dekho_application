package com.example.cricdekho.ui.matchdetails

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cricdekho.R
import com.example.cricdekho.databinding.FragmentFantasyMatchBinding
import com.example.cricdekho.data.model.InfoTeamList

class FantasyMatchFragment : Fragment() {
    private lateinit var binding: FragmentFantasyMatchBinding
    private lateinit var infoTeam1Adapter: InfoTeam1Adapter
    private lateinit var infoTeam2Adapter: InfoTeam2Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentFantasyMatchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initView()
    }

    private fun initView() {
        setUpTeam1Adapter()
        setUpTeam2Adapter()
    }

    private fun setUpTeam1Adapter() {
        infoTeam1Adapter = InfoTeam1Adapter()
        binding.recyclerViewTeam1.layoutManager = LinearLayoutManager(requireContext())
        val infoTeamList = ArrayList<InfoTeamList>()
        for (i in 1..11) {
            infoTeamList.add(
                InfoTeamList(
                    R.drawable.ic_player, "Sai Sudharsan", "All"
                )
            )
        }
        infoTeam1Adapter.addAll(infoTeamList, false)
        binding.recyclerViewTeam1.adapter = infoTeam1Adapter
        infoTeam1Adapter.notifyDataSetChanged()
    }

    private fun setUpTeam2Adapter() {
        infoTeam2Adapter = InfoTeam2Adapter()
        binding.recyclerViewTeam2.layoutManager = LinearLayoutManager(requireContext())
        val infoTeamList = ArrayList<InfoTeamList>()
        for (i in 1..11) {
            infoTeamList.add(
                InfoTeamList(
                    R.drawable.ic_player, "James Coles", "All"
                )
            )
        }
        infoTeam2Adapter.addAll(infoTeamList, false)
        binding.recyclerViewTeam2.adapter = infoTeam2Adapter
        infoTeam2Adapter.notifyDataSetChanged()
    }

    companion object {
        @JvmStatic
        fun newInstance() = FantasyMatchFragment().apply {
            arguments = Bundle().apply {}
        }
    }
}