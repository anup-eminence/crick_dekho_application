package com.example.cricdekho.ui.matchdetails

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cricdekho.R
import com.example.cricdekho.databinding.FragmentCommentaryBinding
import com.example.cricdekho.data.model.CommentaryList

class CommentaryFragment : Fragment() {
    private lateinit var binding: FragmentCommentaryBinding
    private lateinit var commentaryAdapter: CommentaryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCommentaryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initView()
    }

    private fun initView() {
        setUpAdapter()
    }

    private fun setUpAdapter() {
        commentaryAdapter = CommentaryAdapter()
//        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
//        (binding.recyclerView.layoutManager as LinearLayoutManager).reverseLayout = true
//        (binding.recyclerView.layoutManager as LinearLayoutManager).stackFromEnd = true

        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext()).apply {
            reverseLayout = true
            stackFromEnd = true
        }


        val commentaryList = ArrayList<CommentaryList>()
        for (i in 0..10) {
            commentaryList.add(
                CommentaryList(
                    "$i.1",
                    "$i.2",
                    "$i.3",
                    "$i.4",
                    "$i.5",
                    "$i.6",
                    "1",
                    "0",
                    "1",
                    "1",
                    "0",
                    "1",
                    getString(R.string.txt),
                    getString(R.string.txt),
                    getString(R.string.txt),
                    getString(R.string.txt),
                    getString(R.string.txt),
                    getString(R.string.txt),
                    "102/3",
                    "${i + 1}",
                    "Tom Hartley",
                    "Shoaib Bashir",
                    "Mukesh Kumar",
                    "4 Runs",
                    "30 (20)",
                    "0 (0)",
                    "0 /10",
                    getString(R.string.txt),
                )
            )
        }
        commentaryAdapter.addAll(commentaryList, false)
        binding.recyclerView.adapter = commentaryAdapter
        commentaryAdapter.notifyDataSetChanged()
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            CommentaryFragment().apply {
                arguments = Bundle().apply {
                }
            }
    }
}