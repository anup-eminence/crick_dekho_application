package com.example.cricdekho.data.model.getCricketMainTabs

data class Data(
    val name: String,
    val slug: String
)