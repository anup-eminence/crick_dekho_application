package com.example.cricdekho.ui.matchdetails

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemScorecardBinding
import com.example.cricdekho.data.model.ScoreCardTabList
import easyadapter.dc.com.library.EasyAdapter

class ScoreCardAdapter :
    EasyAdapter<ScoreCardTabList, ItemScorecardBinding>(R.layout.item_scorecard) {
    override fun onBind(binding: ItemScorecardBinding, model: ScoreCardTabList) {
        binding.apply {
            tvTabText.text = model.tabText
        }
    }

    override fun onCreatingHolder(binding: ItemScorecardBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
    }
}