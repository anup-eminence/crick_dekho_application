package com.example.cricdekho.data.model

data class HomeExtraNewsList(
    val image1: Int,
    val text1: String,
    val time1: String,
    val image2: Int,
    val text2: String,
    val time2: String,
    val image3: Int,
    val text3: String,
    val time3: String,
)