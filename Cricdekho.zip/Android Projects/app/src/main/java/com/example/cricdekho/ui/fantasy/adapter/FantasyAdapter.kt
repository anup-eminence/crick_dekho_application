package com.example.cricdekho.ui.fantasy.adapter

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemFantasyBinding
import com.example.cricdekho.data.model.FantasyList
import easyadapter.dc.com.library.EasyAdapter

class FantasyAdapter : EasyAdapter<FantasyList, ItemFantasyBinding>(R.layout.item_fantasy) {
    override fun onBind(binding: ItemFantasyBinding, model: FantasyList) {
        binding.apply {
            tvText.text = model.title
        }
    }

    override fun onCreatingHolder(binding: ItemFantasyBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
        binding.tvText.setOnClickListener(easyHolder.clickListener)
    }
}