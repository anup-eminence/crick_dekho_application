package com.example.cricdekho.ui.matchdetails

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cricdekho.databinding.FragmentScoreCardBinding
import com.example.cricdekho.data.model.BowlersList
import com.example.cricdekho.data.model.ScoreCardTabList
import com.example.cricdekho.data.model.TotalScoreList
import com.example.cricdekho.data.model.WicketsList

class ScoreCardFragment : Fragment() {
    private lateinit var binding: FragmentScoreCardBinding
    private lateinit var scoreCardAdapter: ScoreCardAdapter
    private lateinit var totalScoreAdapter: TotalScoreAdapter
    private lateinit var bowlersAdapter: BowlersAdapter
    private lateinit var wicketsAdapter: WicketsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentScoreCardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initView()
    }

    private fun initView() {
        setUpTabAdapter()
        setUpScoreAdapter()
        setUpBowlerAdapter()
        setUpWicketAdapter()
    }

    private fun setUpTabAdapter() {
        scoreCardAdapter = ScoreCardAdapter()
        binding.recyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        val scoreCardTabList = ArrayList<ScoreCardTabList>()
        for (i in 1..2) {
            scoreCardTabList.add(
                ScoreCardTabList(
                    "NZ 1st Inning"
                )
            )
        }
        scoreCardAdapter.addAll(scoreCardTabList, false)
        binding.recyclerView.adapter = scoreCardAdapter
        scoreCardAdapter.notifyDataSetChanged()
    }

    private fun setUpScoreAdapter() {
        totalScoreAdapter = TotalScoreAdapter()
        binding.recyclerViewTotalScore.layoutManager = LinearLayoutManager(requireContext())
        val totalScoreList = ArrayList<TotalScoreList>()
        for (i in 1..8) {
            totalScoreList.add(
                TotalScoreList(
                    "Sai Sudharsan", "c OG Robinson b MD Fisher", "20", "52", "2", "1", "50"
                )
            )
        }
        totalScoreAdapter.addAll(totalScoreList, false)
        binding.recyclerViewTotalScore.adapter = totalScoreAdapter
        totalScoreAdapter.notifyDataSetChanged()
    }

    private fun setUpBowlerAdapter() {
        bowlersAdapter = BowlersAdapter()
        binding.recyclerViewBowlers.layoutManager = LinearLayoutManager(requireContext())
        val bowlersList = ArrayList<BowlersList>()
        for (i in 1..8) {
            bowlersList.add(
                BowlersList(
                    "Matthew Fisher", "25", "3", "40", "2", "5"
                )
            )
        }
        bowlersAdapter.addAll(bowlersList, false)
        binding.recyclerViewBowlers.adapter = bowlersAdapter
        bowlersAdapter.notifyDataSetChanged()
    }

    private fun setUpWicketAdapter() {
        wicketsAdapter = WicketsAdapter()
        binding.recyclerViewWickets.layoutManager = LinearLayoutManager(requireContext())
        val wicketsList = ArrayList<WicketsList>()
        for (i in 1..8) {
            wicketsList.add(
                WicketsList(
                    "Tilak Varma", "c O Price b JM Coles", "3-148", "48.2"
                )
            )
        }
        wicketsAdapter.addAll(wicketsList, false)
        binding.recyclerViewWickets.adapter = wicketsAdapter
        wicketsAdapter.notifyDataSetChanged()
    }

    companion object {
        @JvmStatic
        fun newInstance() = ScoreCardFragment().apply {
            arguments = Bundle().apply {}
        }
    }
}