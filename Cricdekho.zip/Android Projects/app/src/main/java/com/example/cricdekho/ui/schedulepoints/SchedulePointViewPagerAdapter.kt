package com.example.cricdekho.ui.schedulepoints

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.cricdekho.ui.schedulepoints.points.PointsTableFragment
import com.example.cricdekho.ui.schedulepoints.schedule.ScheduleFragment

class SchedulePointViewPagerAdapter(fragmentActivity: FragmentActivity) :
    FragmentStateAdapter(fragmentActivity) {
    override fun getItemCount(): Int {
        return 2
    }

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> ScheduleFragment()
            1 -> PointsTableFragment()
            else -> throw IndexOutOfBoundsException("Invalid position $position")
        }
    }
}