package com.example.cricdekho.ui.schedulepoints.points

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemPointTableBinding
import com.example.cricdekho.data.model.PointTableList
import easyadapter.dc.com.library.EasyAdapter

class PointTableAdapter :
    EasyAdapter<PointTableList, ItemPointTableBinding>(R.layout.item_point_table) {
    override fun onBind(binding: ItemPointTableBinding, model: PointTableList) {
        binding.apply {
            ivImage.setImageResource(model.flag)
            tvNumber.text = model.number
            tvPlayer.text = model.player
            tvText1.text = model.p
            tvText2.text = model.w
            tvText3.text = model.l
            tvText4.text = model.d
            tvText5.text = model.nrr
            tvText6.text = model.pts
        }
    }

    override fun onCreatingHolder(binding: ItemPointTableBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
        binding.tvPlayer.setOnClickListener(easyHolder.clickListener)
    }
}