package com.example.cricdekho.data.model

data class HomeTrendingList(
    val profileImage: Int,
    val name: String,
    val userName: String,
    val description: String,
    val postImage: Int
)
