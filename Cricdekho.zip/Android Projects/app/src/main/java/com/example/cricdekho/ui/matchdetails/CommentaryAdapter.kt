package com.example.cricdekho.ui.matchdetails

import androidx.core.content.ContextCompat
import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemCommentaryBinding
import com.example.cricdekho.data.model.CommentaryList
import easyadapter.dc.com.library.EasyAdapter

class CommentaryAdapter :
    EasyAdapter<CommentaryList, ItemCommentaryBinding>(R.layout.item_commentary) {
    override fun onBind(binding: ItemCommentaryBinding, model: CommentaryList) {
        binding.apply {
            tvBowl1.text = model.bowl1
            tvBowl2.text = model.bowl2
            tvBowl3.text = model.bowl3
            tvBowl4.text = model.bowl4
            tvBowl5.text = model.bowl5
            tvBowl6.text = model.bowl6

            tvRun1.text = model.bowlRun1
            tvRun2.text = model.bowlRun2
            tvRun3.text = model.bowlRun3
            tvRun4.text = model.bowlRun4
            tvRun5.text = model.bowlRun5
            tvRun6.text = model.bowlRun6

            tvText1.text = model.bowlTxt1
            tvText2.text = model.bowlTxt2
            tvText3.text = model.bowlTxt3
            tvText4.text = model.bowlTxt4
            tvText5.text = model.bowlTxt5
            tvText6.text = model.bowlTxt6

            txtScore.text = model.totalScore
            txtOver.text = model.totalOver

            tvBatter1.text = model.batsMenName1
            tvBatter2.text = model.batsMenName2
            tvBowler.text = model.bowlerName

            tvRuns.text = model.run
            tvBatterRun1.text = model.batsMenRun1
            tvBatterRun2.text = model.batsMenRun2
            tvBowlersBall.text = model.bowlersBall

            tvText.text = model.text

            tvR1.setBackgroundResource(R.drawable.bg_blue_circle_shape_fill)
            tvR1.setTextColor(ContextCompat.getColor(root.context, R.color.white))
        }
    }

    override fun onCreatingHolder(binding: ItemCommentaryBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
    }
}