package com.example.cricdekho.ui.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cricdekho.R
import com.example.cricdekho.data.model.HomeExtraNewsList
import com.example.cricdekho.data.model.HomeList
import com.example.cricdekho.data.model.HomeNewsList
import com.example.cricdekho.data.model.HomeTrendingList
import com.example.cricdekho.data.model.getCricketMainTabs.ResponseHomeFeature
import com.example.cricdekho.data.model.getCricketMatches.ResponseHomeMatch
import com.example.cricdekho.data.remote.ApiService
import com.example.cricdekho.databinding.FragmentHomeBinding
import com.example.cricdekho.ui.home.adapter.HomeAdapter
import com.example.cricdekho.ui.home.adapter.HomeExtraNewsAdapter
import com.example.cricdekho.ui.home.adapter.HomeFeatureAdapter
import com.example.cricdekho.ui.home.adapter.HomeNewsAdapter
import com.example.cricdekho.ui.home.adapter.HomeTrendingAdapter
import com.example.cricdekho.util.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding
    private lateinit var homeFeatureAdapter: HomeFeatureAdapter
    private lateinit var homeAdapter: HomeAdapter
    private lateinit var homeNewsAdapter: HomeNewsAdapter
    private lateinit var homeTrendingAdapter: HomeTrendingAdapter
    private lateinit var homeExtraNewsAdapter: HomeExtraNewsAdapter

    val responseHomeFeature = ArrayList<ResponseHomeFeature>()
    val responseHomeMatch = ArrayList<ResponseHomeMatch>()
    private var clickTab: String = "featured"

    private var selectedTextView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initView()
        setOnClickListener()
    }

    private fun initView() {
        callHomeFeatureApi()

        setUpAdapter()
//        setUpFeatureAdapter()
        setUpNewsAdapter()
        setUpTrendingAdapter()
        setUpExtraNewsAdapter()
        selectTextView(binding.tvLatestNews)
    }

    private fun setOnClickListener() {
        binding.tvLatestNews.setOnClickListener {
            selectTextView(binding.tvLatestNews)
        }
        binding.tvMostPopular.setOnClickListener {
            selectTextView(binding.tvMostPopular)
        }
    }

    private fun callHomeFeatureApi() {
        val apiService = RetrofitClient.retrofit.create(ApiService::class.java)
        val call: Call<ResponseHomeFeature> = apiService.getCricketTab()
        call.enqueue(object : Callback<ResponseHomeFeature> {
            override fun onResponse(
                call: Call<ResponseHomeFeature>,
                response: Response<ResponseHomeFeature>
            ) {
                if (response.isSuccessful) {
                    val data: ResponseHomeFeature? = response.body()
                    if (data != null) {
                        responseHomeFeature.add(data)
                    }
                    setUpFeatureAdapter()
                    Log.e("Data-tab------>", responseHomeFeature.toString())
                } else {
                    // Handle the error
                }
            }

            override fun onFailure(call: Call<ResponseHomeFeature>, t: Throwable) {
                Log.e("tab-error--------->", t.message.toString())
            }
        })
    }

    private fun callHomeMatchApi() {
        val apiService = RetrofitClient.retrofit.create(ApiService::class.java)
        val call: Call<ResponseHomeMatch> = apiService.getCricketMatches(clickTab)
        Log.e("call", "-----------------------call")

        call.enqueue(object : Callback<ResponseHomeMatch> {
            override fun onResponse(call: Call<ResponseHomeMatch>, response: Response<ResponseHomeMatch>) {
                if (response.isSuccessful) {
                    val data: ResponseHomeMatch? = response.body()

                    if (data != null) {
                        responseHomeMatch.add(data)
                    }
//                    setUpAdapter()
                    Log.e("Data-match------>", responseHomeMatch.toString())
                } else {
                    // Handle the error
                }
            }

            override fun onFailure(call: Call<ResponseHomeMatch>, t: Throwable) {
                Log.e("match-error--------->", t.message.toString())
            }
        })
    }

    private fun selectTextView(textView: TextView) {
        if (selectedTextView != textView) {
            selectedTextView?.let {
                it.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                it.background = null
            }
            selectedTextView = textView
            textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            textView.setBackgroundResource(R.drawable.bg_grey_shape)
        }
    }

    private fun setUpAdapter() {
        homeAdapter = HomeAdapter()
        binding.recyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        val homeList = ArrayList<HomeList>()
        for (i in 1..8) {
            homeList.add(
                HomeList(
                    R.drawable.ic_in,
                    R.drawable.ic_nz,
                    "IND",
                    "NZ",
                    "Match Delayed Due To Rain",
                    "149/9 (20 ov)",
                    "149/9 (20 ov)"
                )
            )
        }
        homeAdapter.addAll(homeList, false)
        binding.recyclerView.adapter = homeAdapter
        homeAdapter.notifyDataSetChanged()

        homeAdapter.setRecyclerViewItemClick { itemView, model ->
            when (itemView.id) {
                R.id.tvSchedule -> {
                    findNavController().navigate(R.id.action_homeFragment_to_schedulePointsFragment)
                }

                R.id.tvPoints -> {
                    findNavController().navigate(R.id.action_homeFragment_to_schedulePointsFragment)
                }

                R.id.clItem -> {
                    findNavController().navigate(R.id.action_homeFragment_to_matchDetailsFragment)
                }
            }
        }
    }

    private fun setUpFeatureAdapter() {
        homeFeatureAdapter = HomeFeatureAdapter()
        binding.recyclerViewFeatures.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)

        homeFeatureAdapter.addAll(responseHomeFeature[0].data, false)
        binding.recyclerViewFeatures.adapter = homeFeatureAdapter
        homeFeatureAdapter.notifyDataSetChanged()

        homeFeatureAdapter.setRecyclerViewItemClick { itemView, model ->
            when (itemView.id) {
                R.id.tvText -> {
                    clickTab = model.slug
                    Log.e("Clicked--------", "Clicked-  ${model.slug}")
                    callHomeMatchApi()
                }
            }
        }
    }

    private fun setUpNewsAdapter() {
        homeNewsAdapter = HomeNewsAdapter()
        binding.recyclerViewNews.layoutManager = LinearLayoutManager(requireContext())
        val homeNewsList = ArrayList<HomeNewsList>()
        for (i in 1..5) {
            homeNewsList.add(
                HomeNewsList(
                    "$i",
                    "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content."
                )
            )
        }
        homeNewsAdapter.addAll(homeNewsList, false)
        binding.recyclerViewNews.adapter = homeNewsAdapter
        homeNewsAdapter.notifyDataSetChanged()
    }

    private fun setUpTrendingAdapter() {
        homeTrendingAdapter = HomeTrendingAdapter()
        binding.recyclerViewTrending.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        val homeTrendingList = ArrayList<HomeTrendingList>()
        for (i in 1..20) {
            homeTrendingList.add(
                HomeTrendingList(
                    R.drawable.ic_nz,
                    "Cricdekho",
                    "@cricdekho",
                    "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.",
                    R.drawable.ic_image
                )
            )
        }
        homeTrendingAdapter.addAll(homeTrendingList, false)
        binding.recyclerViewTrending.adapter = homeTrendingAdapter
        homeTrendingAdapter.notifyDataSetChanged()
    }

    private fun setUpExtraNewsAdapter() {
        homeExtraNewsAdapter = HomeExtraNewsAdapter()
        binding.recyclerViewExtraNews.layoutManager = LinearLayoutManager(requireContext())
        val homeExtraNewsList = ArrayList<HomeExtraNewsList>()
        for (i in 1..30) {
            homeExtraNewsList.add(
                HomeExtraNewsList(
                    R.drawable.ic_image,
                    "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.",
                    "35 minutes ago",
                    R.drawable.ic_image,
                    "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.",
                    "35 minutes ago",
                    R.drawable.ic_image,
                    "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.",
                    "35 minutes ago"
                )
            )
        }
        homeExtraNewsAdapter.addAll(homeExtraNewsList, false)
        binding.recyclerViewExtraNews.adapter = homeExtraNewsAdapter
        homeExtraNewsAdapter.notifyDataSetChanged()
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) = HomeFragment().apply {
            arguments = Bundle().apply {}
        }
    }
}