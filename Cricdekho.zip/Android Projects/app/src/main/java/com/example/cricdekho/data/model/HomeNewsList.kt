package com.example.cricdekho.data.model

data class HomeNewsList(val number: String, val news: String)
