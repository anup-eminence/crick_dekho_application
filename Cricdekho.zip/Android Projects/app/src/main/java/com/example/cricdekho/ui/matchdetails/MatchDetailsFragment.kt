package com.example.cricdekho.ui.matchdetails

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.cricdekho.R
import com.example.cricdekho.databinding.FragmentMatchDetailsBinding
import com.example.cricdekho.ui.activity.HomeActivity
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MatchDetailsFragment : Fragment() {
    private lateinit var binding: FragmentMatchDetailsBinding
    private lateinit var matchDetailViewPagerAdapter: MatchDetailViewPagerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentMatchDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initView()
    }

    private fun initView() {
        view?.postDelayed({
            selectFirstTab()
        }, 100)
        setViewPagerAdapter()

        val yourActivity = activity as? HomeActivity
        yourActivity?.showToolBarMethod(
            title = "Match Details",
            menu = false,
            logo = false,
            search = false,
            setting = false,
            back = true,
            share = true
        )
    }

    private fun setViewPagerAdapter() {
        matchDetailViewPagerAdapter = MatchDetailViewPagerAdapter(requireActivity())
        binding.viewPager.adapter = matchDetailViewPagerAdapter

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            when (position) {
                0 -> tab.text = "Info"
                1 -> tab.text = "Fantasy"
                2 -> tab.text = "Commentary"
                3 -> tab.text = "Scorecard"
                4 -> tab.text = "Trending"
            }
        }.attach()

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                tab?.view?.background = ContextCompat.getDrawable(
                    requireContext(), R.drawable.bg_grey_shape
                )
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                tab?.view?.background = null
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }
        })
    }

    private fun selectFirstTab() {
        val firstTab = binding.tabLayout.getTabAt(0)
        firstTab?.let {
            it.select()
            it.view.background =
                ContextCompat.getDrawable(requireContext(), R.drawable.bg_grey_shape)
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() = MatchDetailsFragment().apply {
            arguments = Bundle().apply {}
        }
    }
}