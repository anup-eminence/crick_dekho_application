package com.example.cricdekho.data.model

data class CommentaryList(
    val bowl1: String,
    val bowl2: String,
    val bowl3: String,
    val bowl4: String,
    val bowl5: String,
    val bowl6: String,

    val bowlRun1: String,
    val bowlRun2: String,
    val bowlRun3: String,
    val bowlRun4: String,
    val bowlRun5: String,
    val bowlRun6: String,

    val bowlTxt1: String,
    val bowlTxt2: String,
    val bowlTxt3: String,
    val bowlTxt4: String,
    val bowlTxt5: String,
    val bowlTxt6: String,

    val totalScore: String,
    val totalOver: String,

    val batsMenName1: String,
    val batsMenName2: String,
    val bowlerName: String,

    val run: String,
    val batsMenRun1: String,
    val batsMenRun2: String,
    val bowlersBall: String,

    val text: String
)