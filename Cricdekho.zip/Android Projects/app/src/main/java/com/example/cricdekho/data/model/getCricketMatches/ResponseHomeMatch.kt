package com.example.cricdekho.data.model.getCricketMatches

data class ResponseHomeMatch(
    val `data`: List<Data>,
    val message: String
)