package com.example.cricdekho.data.model

data class ScheduleList(
    val date: String,
    val title: String,
    val flag1: Int,
    val flag2: Int,
    val match1: String,
    val match2: String,
    val runs1: String,
    val runs2: String,
    val decision: String
)