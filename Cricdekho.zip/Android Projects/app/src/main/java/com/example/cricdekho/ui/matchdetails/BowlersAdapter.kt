package com.example.cricdekho.ui.matchdetails

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemBowlersBinding
import com.example.cricdekho.data.model.BowlersList
import easyadapter.dc.com.library.EasyAdapter

class BowlersAdapter : EasyAdapter<BowlersList, ItemBowlersBinding>(R.layout.item_bowlers) {
    override fun onBind(binding: ItemBowlersBinding, model: BowlersList) {
        binding.apply {
            tvBowlers.text = model.player
            tvO.text = model.o
            tvM.text = model.m
            tvRBowler.text = model.r
            tvW.text = model.w
            tvEco.text = model.eco
        }
    }

    override fun onCreatingHolder(binding: ItemBowlersBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
    }
}