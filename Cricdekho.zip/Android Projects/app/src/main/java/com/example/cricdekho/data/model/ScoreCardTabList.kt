package com.example.cricdekho.data.model

data class ScoreCardTabList(val tabText: String)