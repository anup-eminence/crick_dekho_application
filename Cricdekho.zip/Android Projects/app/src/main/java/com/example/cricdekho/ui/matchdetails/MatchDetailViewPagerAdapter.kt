package com.example.cricdekho.ui.matchdetails

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class MatchDetailViewPagerAdapter(fragmentActivity: FragmentActivity) :
    FragmentStateAdapter(fragmentActivity) {
    override fun getItemCount(): Int {
        return 5
    }

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> InfoFragment()
            1 -> FantasyMatchFragment()
            2 -> CommentaryFragment()
            3 -> ScoreCardFragment()
            4 -> TrendingFragment()
            else -> throw IndexOutOfBoundsException("Invalid position $position")
        }
    }
}