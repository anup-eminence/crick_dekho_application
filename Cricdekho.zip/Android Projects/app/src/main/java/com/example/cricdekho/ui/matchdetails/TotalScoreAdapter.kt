package com.example.cricdekho.ui.matchdetails

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemTotalScoreBinding
import com.example.cricdekho.data.model.TotalScoreList
import easyadapter.dc.com.library.EasyAdapter

class TotalScoreAdapter :
    EasyAdapter<TotalScoreList, ItemTotalScoreBinding>(R.layout.item_total_score) {
    override fun onBind(binding: ItemTotalScoreBinding, model: TotalScoreList) {
        binding.apply {
            tvBatters.text = model.player
            tvText.text = model.txt
            tvR.text = model.r
            tvB.text = model.b
            tv4s.text = model._4s
            tv6s.text = model._6s
            tvSR.text = model.sr
        }
    }

    override fun onCreatingHolder(binding: ItemTotalScoreBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
    }
}