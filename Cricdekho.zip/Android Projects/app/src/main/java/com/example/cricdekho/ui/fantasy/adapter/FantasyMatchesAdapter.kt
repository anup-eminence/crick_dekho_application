package com.example.cricdekho.ui.fantasy.adapter

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemFantasyMatchesBinding
import com.example.cricdekho.data.model.FantasyMatchList
import easyadapter.dc.com.library.EasyAdapter

class FantasyMatchesAdapter :
    EasyAdapter<FantasyMatchList, ItemFantasyMatchesBinding>(R.layout.item_fantasy_matches) {
    override fun onBind(binding: ItemFantasyMatchesBinding, model: FantasyMatchList) {
        binding.apply {
            tvMatch.text = model.title
            tvMatch1.text = model.match1
            tvMatch2.text = model.match2
            ivImage1.setImageResource(model.image1)
            ivImage2.setImageResource(model.image2)
            tvTime.text = model.time
        }
    }

    override fun onCreatingHolder(binding: ItemFantasyMatchesBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
        binding.clItem.setOnClickListener(easyHolder.clickListener)
    }
}