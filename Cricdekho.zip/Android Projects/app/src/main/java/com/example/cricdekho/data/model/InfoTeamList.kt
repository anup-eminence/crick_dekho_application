package com.example.cricdekho.data.model

data class InfoTeamList(val profile: Int, val playerName: String, val playerExpert: String)
