package com.example.cricdekho.data.remote

import com.example.cricdekho.data.model.getCricketMainTabs.ResponseHomeFeature
import com.example.cricdekho.data.model.getCricketMatches.ResponseHomeMatch
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("getCricketMainTabs")
    fun getCricketTab(): Call<ResponseHomeFeature>

    @GET("getCricketMatches/")
    fun getCricketMatches(@Query("tournament_slug") partournament_slug: String): Call<ResponseHomeMatch>
}