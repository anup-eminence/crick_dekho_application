package com.example.cricdekho.ui.matchdetails

import com.example.cricdekho.R
import com.example.cricdekho.databinding.ItemWicketsBinding
import com.example.cricdekho.data.model.WicketsList
import easyadapter.dc.com.library.EasyAdapter

class WicketsAdapter : EasyAdapter<WicketsList, ItemWicketsBinding>(R.layout.item_wickets) {
    override fun onBind(binding: ItemWicketsBinding, model: WicketsList) {
        binding.apply {
            tvBattersWicket.text = model.player
            tvText.text = model.txt
            tvScore.text = model.score
            tvOver.text = model.over
        }
    }

    override fun onCreatingHolder(binding: ItemWicketsBinding, easyHolder: EasyHolder) {
        super.onCreatingHolder(binding, easyHolder)
        binding.root.setOnClickListener(easyHolder.clickListener)
    }
}