package com.example.cricdekho.ui.schedulepoints.points

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cricdekho.R
import com.example.cricdekho.databinding.FragmentPointsTableBinding
import com.example.cricdekho.data.model.PointTableList

class PointsTableFragment : Fragment() {
    private lateinit var binding: FragmentPointsTableBinding
    private lateinit var pointTableAdapter: PointTableAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentPointsTableBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initView()
    }

    private fun initView() {
        setUpAdapter()
    }

    private fun setUpAdapter() {
        pointTableAdapter = PointTableAdapter()
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        val pointTableList = ArrayList<PointTableList>()
        for (i in 1..8) {
            pointTableList.add(
                PointTableList(
                    "$i", R.drawable.ic_nz, "DSG", "9", "7", "2", "0", "1.60", "10"
                )
            )
        }
        pointTableAdapter.addAll(pointTableList, false)
        binding.recyclerView.adapter = pointTableAdapter
        pointTableAdapter.notifyDataSetChanged()
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) = PointsTableFragment().apply {
            arguments = Bundle().apply {}
        }
    }
}